MEGAMC PREMIUM SETY - RESOURCE PACK 1.18.2

Co robi pack:
- Podmienia wygląd itemów z CustomModelData:
  1101-1105 = Set Wojownika
  1201-1205 = Set Tanka
  1301-1305 = Set Mega

Ważne ograniczenie 1.18.2 bez OptiFine/CIT:
- Miecze będą miały custom wygląd w ręce i ekwipunku.
- Części pancerza będą miały custom wygląd jako itemy w ekwipunku i na ziemi.
- Sam wygląd pancerza na postaci NIE zmieni się w pełni bez dodatkowych rozwiązań klienckich.

Jak użyć:
1. NIE rozpakowuj ZIP-a dla graczy.
2. Wrzuć ZIP na hosting / direct link.
3. Podłącz link w server.properties:
   resource-pack=<twoj_bezposredni_link_do_zip>
   resource-pack-sha1=<opcjonalny_sha1>

albo użyj pluginu do wymuszania resource packa.

Pliki z komendami:
- 01_give_set_wojownika.txt, 02..., 03... to tylko ściągi z komendami. Nie wrzuca się ich do folderu pluginu.
- Otwórz je notatnikiem i skopiuj komendy do konsoli albo na OP.
- 04_zapis_do_serveritem.txt: po otrzymaniu itemu trzymaj go w ręce i wpisz odpowiednie /serveritem save
- 05_komendy_nadawania_po_zapisie.txt: używaj później do rozdawania gotowych itemów
- 06_rozpiska_itemow.txt: opis, co jest czym
